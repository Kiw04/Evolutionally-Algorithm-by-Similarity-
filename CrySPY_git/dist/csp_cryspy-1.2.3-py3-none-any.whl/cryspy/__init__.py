from .util.utility import get_version
__version__ = get_version()